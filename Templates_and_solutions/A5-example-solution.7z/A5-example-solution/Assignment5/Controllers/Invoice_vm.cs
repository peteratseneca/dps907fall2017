﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// added...
using System.ComponentModel.DataAnnotations;
using Assignment5.ServiceLayer;

namespace Assignment5.Controllers
{
    // Invoice resource model, could do Add, Base, and WithData
    // Or, just WithData alone, to satisfy the one/single "get all" use case
    public class InvoiceWithData
    {
        [Key]
        public int InvoiceId { get; set; }

        public int CustomerId { get; set; }

        public DateTime InvoiceDate { get; set; }

        [StringLength(70)]
        public string BillingAddress { get; set; }

        [StringLength(40)]
        public string BillingCity { get; set; }

        [StringLength(40)]
        public string BillingState { get; set; }

        [StringLength(40)]
        public string BillingCountry { get; set; }

        [StringLength(10)]
        public string BillingPostalCode { get; set; }

        public decimal Total { get; set; }

        // Composed properties, extra data
        public string CustomerLastName { get; set; }
        public string CustomerFirstName { get; set; }
        public string CustomerCompany { get; set; }
    }

    // For the hypermedia representation
    public class InvoiceWithDataAndLinks : InvoiceWithData
    {
        public InvoiceWithDataAndLinks()
        {
            links = new List<link>();
        }

        public ICollection<link> links { get; set; }
    }

}
