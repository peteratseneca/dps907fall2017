﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// added...
using System.ComponentModel.DataAnnotations;

namespace Assignment5.Controllers
{
    // Resource model class for the "set support rep" command
    public class CustomerSupportRep
    {
        public int CustomerId { get; set; }
        public int SupportRepId { get; set; }
    }
}
