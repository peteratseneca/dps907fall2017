﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Assignment5.ServiceLayer;

namespace Assignment5.Controllers
{
    // Help Page generator will ignore this controller
    [System.Web.Http.Description.ApiExplorerSettings(IgnoreApi = true)]
    public class RootController : ApiController
    {
        // Attention 06 - This controller answers a URI that ends with 'api'
        // It's intended to handle requests to the 'root' URI, 
        // and will return a collection of link relations

        // This controller is called because we added a default value for 'controller'
        // in the App_Start > WebApiConfig class

        // GET: api/Root (or "/api" or "/api/")
        public IHttpActionResult Get()
        {
            // Create a collection of Link objects

            List<link> links = new List<link>();
            links.Add(new link() { rel = "collection", href = "/api/employees", methods = "GET,POST" });
            links.Add(new link() { rel = "edit", href = "/api/employees/{id}", methods = "PUT" });
            links.Add(new link() { rel = "collection", href = "/api/invoices", methods = "GET" });
            links.Add(new link() { rel = "task", href = "/api/customers/{id}/setsupportrep", methods = "PUT" });

            // Create and configure a dictionary to hold the collection
            // We need to return a simple object, so a Dictionary<TKey, TValue> is ideal

            Dictionary<string, List<link>> linkList = new Dictionary<string, List<link>>();
            linkList.Add("Links", links);

            return Ok(linkList);
        }
    }
}
