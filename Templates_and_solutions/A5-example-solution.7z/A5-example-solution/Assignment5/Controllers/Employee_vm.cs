﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Assignment5.ServiceLayer;

namespace Assignment5.Controllers
{
    public class EmployeeAdd
    {
        public EmployeeAdd()
        {
            BirthDate = DateTime.Now.AddYears(-30);
            HireDate = DateTime.Now.AddYears(-1);
        }

        [Required]
        [StringLength(20)]
        public string LastName { get; set; }

        [Required]
        [StringLength(20)]
        public string FirstName { get; set; }

        [StringLength(30)]
        public string Title { get; set; }

        // We will leave this property as-is, so entering a value will be optional
        public int? ReportsTo { get; set; }

        public DateTime? BirthDate { get; set; }

        public DateTime? HireDate { get; set; }

        // Added "Required" to the postal address related properties
        // The design model class doesn't have this annotation
        // However, adding it here improves the quality of the incoming data

        [Required, StringLength(70)]
        public string Address { get; set; }

        [Required, StringLength(40)]
        public string City { get; set; }

        [Required, StringLength(40)]
        public string State { get; set; }

        [Required, StringLength(40)]
        public string Country { get; set; }

        [Required, StringLength(10)]
        public string PostalCode { get; set; }

        [StringLength(24)]
        public string Phone { get; set; }

        [StringLength(24)]
        public string Fax { get; set; }

        [StringLength(60)]
        public string Email { get; set; }
    }

    public class EmployeeBase : EmployeeAdd
    {
        [Key]
        public int EmployeeId { get; set; }
    }

    public class EmployeeWithData : EmployeeBase
    {
        // Composed property name
        // Make a string that has the property names in a chain/sequence
        public string Employee2FirstName { get; set; }
        public string Employee2LastName { get; set; }
    }

    // For the hypermedia representation
    public class EmployeeWithDataAndLinks : EmployeeWithData
    {
        public EmployeeWithDataAndLinks()
        {
            links = new List<link>();
        }

        public ICollection<link> links { get; set; }
    }

    public class EmployeeWithAllData : EmployeeWithData
    {
        // With collection of direct reports
        public EmployeeWithAllData()
        {
            Employee1 = new List<EmployeeBase>();
        }

        public IEnumerable<EmployeeBase> Employee1 { get; set; }
    }

    public class EmployeeEditAddress
    {
        [Key]
        public int EmployeeId { get; set; }

        [Required, StringLength(70)]
        public string Address { get; set; }

        [Required, StringLength(40)]
        public string City { get; set; }

        [Required, StringLength(40)]
        public string State { get; set; }

        [Required, StringLength(40)]
        public string Country { get; set; }

        [Required, StringLength(10)]
        public string PostalCode { get; set; }

    }

}
