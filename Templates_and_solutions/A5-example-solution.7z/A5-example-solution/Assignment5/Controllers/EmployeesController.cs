﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Assignment5.ServiceLayer;

namespace Assignment5.Controllers
{
    public class EmployeesController : ApiController
    {
        // Reference to the data manager
        private Manager m = new Manager();

        // Attention 11 - Employees get all use case
        // Also needs this support:
        // Resource models
        // Manager create-map AutoMapper statement(s)
        // Manager method
        // Must create a hypermedia package and return it

        // GET: api/Employees
        /// <summary>
        /// All employees
        /// </summary>
        /// <returns>Collection of employee objects</returns>
        public IHttpActionResult Get()
        {
            var c = m.EmployeeGetAllWithData();

            // New return value, with link relations

            // First, transform the object graph into one that includes the link property
            var lc = m.mapper.Map<IEnumerable<EmployeeWithDataAndLinks>>(c);

            // Next, create a hypermedia representation package
            var hr = new MediaTypeExample();

            // Go through each item in the collection, and configure link relations
            foreach (var item in lc)
            {
                // Add a link to "self" (il is "item link")
                var il = new link();
                il.rel = "self";
                il.href = $"/api/employees/{item.EmployeeId}";
                item.links.Add(il);

                // Add a link to "collection" (cl is "collection link)
                var cl = new link();
                cl.rel = "collection";
                cl.href = "/api/employees";
                item.links.Add(cl);

                // Add this updated item to the hypermedia representation package
                hr.data.Add(item);
            }

            // Finish off the configuration of the hypermedia representation...

            // How many items?
            hr.count = hr.data.Count;

            // Configure the link for the collection to refer to itself
            var l = new link();
            l.rel = "self";
            l.href = "/api/employees";

            // Add it
            hr.links.Add(l);

            // Return the result
            return Ok(hr);
        }

        // Attention 12 - Employees get one use case
        // Also needs this support:
        // Resource models
        // Manager create-map AutoMapper statement(s)
        // Manager method
        // Must create a hypermedia package and return it

        // GET: api/Employees/5
        /// <summary>
        /// One employee, by its identifier
        /// </summary>
        /// <param name="id">Employee identifier</param>
        /// <returns>Employee object</returns>
        public IHttpActionResult Get(int? id)
        {
            // Attempt to fetch the object
            var o = m.EmployeeGetByIdWithAllData(id.GetValueOrDefault());

            // Continue?
            if (o == null)
            {
                return NotFound();
            }
            else
            {
                // New return value

                // Make a version of the object that includes a link relation
                var lo = m.mapper.Map<EmployeeWithDataAndLinks>(o);

                // Configure the link relation
                var l = new link();
                l.rel = "self";
                l.href = $"/api/employees/{o.EmployeeId}";
                lo.links.Add(l);

                // Create and configure a package (hypermedia representation)
                var hr = new MediaTypeExample();

                hr.data.Add(lo);
                hr.count = hr.data.Count;
                hr.links.Add(l);

                // Add a link to the parent collection
                var lc = new link();
                lc.rel = "collection";
                lc.href = "/api/employees";
                hr.links.Add(lc);

                return Ok(hr);
            }
        }

        // Attention 13 - Employees add new use case
        // Also needs this support:
        // Resource models
        // Manager create-map AutoMapper statement(s)
        // Manager method
        // Must create a hypermedia package and return it

        // POST: api/Employees
        /// <summary>
        /// Add new employee
        /// </summary>
        /// <param name="newItem">New employee object</param>
        /// <returns>Employee object</returns>
        public IHttpActionResult Post([FromBody]EmployeeAdd newItem)
        {
            // Ensure that the URI is clean (and does not have an id parameter)
            if (Request.GetRouteData().Values["id"] != null) { return BadRequest("Invalid request URI"); }

            // Ensure that a "newItem" is in the entity body
            if (newItem == null) { return BadRequest("Must send an entity body with the request"); }

            // Ensure that we can use the incoming data
            if (!ModelState.IsValid) { return BadRequest(ModelState); }

            // Attempt to add the new object
            var addedItem = m.EmployeeAdd(newItem);

            // Continue?
            if (addedItem == null) { return BadRequest("Cannot add the object"); }

            // HTTP 201 with the new object in the entity body
            // Notice how to create the URI for the Location header
            var uri = Url.Link("DefaultApi", new { id = addedItem.EmployeeId });

            // New return value

            // Make a version of the object that includes a link relation
            var lo = m.mapper.Map<EmployeeWithDataAndLinks>(addedItem);

            // Configure the link relation
            var l = new link();
            l.rel = "self";
            l.href = $"/api/employees/{addedItem.EmployeeId}";
            lo.links.Add(l);

            // Create and configure a package (hypermedia representation)
            var hr = new MediaTypeExample();

            hr.data.Add(lo);
            hr.count = hr.data.Count;
            hr.links.Add(l);

            // Add a link to the parent collection
            var lc = new link();
            lc.rel = "collection";
            lc.href = "/api/employees";
            hr.links.Add(lc);

            return Created(uri, hr);
        }

        // Attention 14 - Employees edit existing (address) use case
        // Also needs this support:
        // Resource models
        // Manager create-map AutoMapper statement(s)
        // Manager method
        // Must create a hypermedia package and return it

        // PUT: api/Employees/5
        /// <summary>
        /// Edit employee address
        /// </summary>
        /// <param name="id">Employee identifier</param>
        /// <param name="editedItem">Address edit package</param>
        /// <returns>Employee object</returns>
        public IHttpActionResult Put(int? id, [FromBody]EmployeeEditAddress editedItem)
        {
            // Ensure that an "editedItem" is in the entity body
            if (editedItem == null)
            {
                return BadRequest("Must send an entity body with the request");
            }

            // Ensure that the id value in the URI matches the id value in the entity body
            if (id.GetValueOrDefault() != 123)
            {
                return BadRequest("Invalid data in the entity body");
            }

            // Ensure that we can use the incoming data
            if (ModelState.IsValid)
            {
                // Attempt to update the item
                var changedItem = m.EmployeeEditAddress(editedItem);

                // Notice the ApiController convenience methods
                if (changedItem == null)
                {
                    // HTTP 400
                    return BadRequest("Cannot edit the object");
                }
                else
                {
                    // HTTP 200 with the changed item in the entity body
                    // return Ok(changedItem);

                    // New return value

                    // Make a version of the object that includes a link relation
                    var lo = m.mapper.Map<EmployeeWithDataAndLinks>(changedItem);

                    // Configure the link relation
                    var l = new link();
                    l.rel = "self";
                    l.href = $"/api/employees/{changedItem.EmployeeId}";
                    lo.links.Add(l);

                    // Create and configure a package (hypermedia representation)
                    var hr = new MediaTypeExample();

                    hr.data.Add(lo);
                    hr.count = hr.data.Count;
                    hr.links.Add(l);

                    // Add a link to the parent collection
                    var lc = new link();
                    lc.rel = "collection";
                    lc.href = "/api/employees";
                    hr.links.Add(lc);

                    return Ok(hr);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

    }
}
