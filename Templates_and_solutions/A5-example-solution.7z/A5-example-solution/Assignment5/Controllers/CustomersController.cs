﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
// added...
using AutoMapper;

namespace Assignment5.Controllers
{
    public class CustomersController : ApiController
    {
        // Reference
        private Manager m = new Manager();

        // Attention 15 - Customer set-support-rep use case (a command)
        // Also needs this support:
        // Resource models
        // Manager create-map AutoMapper statement(s)
        // Manager method

        // Set support rep action, returns nothing
        /// <summary>
        /// Set/configure a customer's support rep
        /// </summary>
        /// <param name="id">Customer identifier</param>
        /// <param name="item">Customer and support rep data</param>
        [HttpPut]
        [Route("api/customers/{id}/setsupportrep")]
        public void CustomerSetSupportRep(int? id, [FromBody]CustomerSupportRep item)
        {
            // Ensure that an "editedItem" is in the entity body
            if (item == null) { return; }

            // Ensure that the id value in the URI matches the id value in the entity body
            if (id.GetValueOrDefault() != item.CustomerId) { return; }

            // Ensure that we can use the incoming data
            if (ModelState.IsValid)
            {
                // Attempt to update the item
                m.CustomerSetSupportRep(item);
            }
            else
            {
                return;
            }
        }

    }
}
