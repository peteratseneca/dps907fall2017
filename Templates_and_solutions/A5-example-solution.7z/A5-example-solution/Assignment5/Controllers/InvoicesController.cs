﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
// added...
//using AutoMapper;
using Assignment5.ServiceLayer;

namespace Assignment5.Controllers
{
    public class InvoicesController : ApiController
    {
        // Reference
        private Manager m = new Manager();

        // Attention 16 - Invoices get all use case
        // Also needs this support:
        // Resource models
        // Manager create-map AutoMapper statement(s)
        // Manager method
        // Must create a hypermedia package and return it

        // GET: api/Invoices
        /// <summary>
        /// All invoices
        /// </summary>
        /// <returns>Collection of invoice objects</returns>
        public IHttpActionResult Get()
        {
            // Fetch collection
            var c = m.InvoiceGetAll();

            // First, transform the object graph into one that includes the link property
            var lc = m.mapper.Map<IEnumerable<InvoiceWithDataAndLinks>>(c);

            // Next, create a hypermedia representation package
            var hr = new MediaTypeExample();

            // Go through each item in the collection, and configure link relations
            foreach (var item in lc)
            {
                // Add a link to "self" (il is "item link")
                var il = new link();
                il.rel = "self";
                il.href = $"/api/invoices/{item.InvoiceId}";
                item.links.Add(il);

                // Add a link to "collection" (cl is "collection link)
                var cl = new link();
                cl.rel = "collection";
                cl.href = "/api/invoices";
                item.links.Add(cl);

                // Add this updated item to the hypermedia representation package
                hr.data.Add(item);
            }

            // Finish off the configuration of the hypermedia representation...

            // How many items?
            hr.count = hr.data.Count;

            // Configure the link for the collection to refer to itself
            var l = new link();
            l.rel = "self";
            l.href = "/api/invoices";

            // Add it
            hr.links.Add(l);

            // Return the result
            return Ok(hr);

        }

        // GET: api/Invoices/5
        /// <summary>
        /// One customer by its identifier
        /// </summary>
        /// <param name="id">Customer identifier</param>
        /// <returns>(not implemented in this app)</returns>
        public string Get(int id)
        {
            return "not implemented";
        }

    }
}
