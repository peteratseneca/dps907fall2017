﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// new...
using AutoMapper;
using Assignment5.Models;

namespace Assignment5.Controllers
{
    public class Manager
    {
        // Reference to the data context
        private DataContext ds = new DataContext();

        // AutoMapper components
        MapperConfiguration config;
        public IMapper mapper;

        public Manager()
        {
            // If necessary, add your own code here

            // Configure AutoMapper...
            config = new MapperConfiguration(cfg =>
            {
                // Define the mappings below, for example...
                // cfg.CreateMap<SourceType, DestinationType>();
                // cfg.CreateMap<Employee, EmployeeBase>();

                // Create map statements

                // Standard design-to-resource
                cfg.CreateMap<Models.Employee, Controllers.EmployeeBase>();
                cfg.CreateMap<Models.Employee, Controllers.EmployeeWithData>();
                cfg.CreateMap<Models.Employee, Controllers.EmployeeWithAllData>();

                cfg.CreateMap<Models.Invoice, Controllers.InvoiceWithData>();

                // Supports add-new use case
                cfg.CreateMap<Controllers.EmployeeAdd, Models.Employee>();

                // Hypermedia representations
                cfg.CreateMap<Controllers.EmployeeWithData, Controllers.EmployeeWithDataAndLinks>();
                cfg.CreateMap<Controllers.InvoiceWithData, Controllers.InvoiceWithDataAndLinks>();
            });

            mapper = config.CreateMapper();

            // Data-handling configuration

            // Turn off the Entity Framework (EF) proxy creation features
            // We do NOT want the EF to track changes - we'll do that ourselves
            ds.Configuration.ProxyCreationEnabled = false;

            // Also, turn off lazy loading...
            // We want to retain control over fetching related objects
            ds.Configuration.LazyLoadingEnabled = false;
        }

        // Add methods below
        // Controllers will call these methods
        // Ensure that the methods accept and deliver ONLY view model objects and collections
        // The collection return type is almost always IEnumerable<T>

        // Suggested naming convention: Entity + task/action
        // For example:
        // ProductGetAll()
        // ProductGetById()
        // ProductAdd()
        // ProductEdit()
        // ProductDelete()




        // Employee get all, returns extra data
        public IEnumerable<EmployeeWithData> EmployeeGetAllWithData()
        {
            // Fetch the collection
            var c = ds.Employees
                .Include("Employee2")
                .OrderBy(e => e.LastName)
                .ThenBy(e => e.FirstName);

            // Return the results as a collection based on a resource model class
            return mapper.Map<IEnumerable<EmployeeWithData>>(c);
        }

        // Employee get one, returns extra data
        public EmployeeWithAllData EmployeeGetByIdWithAllData(int id)
        {
            // Attempt to fetch the object
            var o = ds.Employees
                .Include("Employee1")
                .Include("Employee2")
                .SingleOrDefault(e => e.EmployeeId == id);

            // Return the result, or null if not found
            return (o == null) ? null : mapper.Map<EmployeeWithAllData>(o);
        }

        // Employee add new, returns extra data
        // Must do a bit more than a normal "add new", because of the association
        // Please be aware that there could be alternative coding plans - 
        // the following plan is not authoritative, and others could work
        public EmployeeWithData EmployeeAdd(EmployeeAdd newItem)
        {
            // Attempt to add the object
            var addedItem = ds.Employees.Add(mapper.Map<Employee>(newItem));

            // If there is a ReportsTo value, then get it
            if (newItem.ReportsTo.HasValue)
            {
                // Attempt to fetch the supervisor
                var s = ds.Employees.Find(newItem.ReportsTo.Value);

                if (s != null)
                {
                    // Configure the supervisor
                    addedItem.Employee2 = s;
                }
            }

            ds.SaveChanges();

            // Return the result, or null if there was an error
            return (addedItem == null) ? null : mapper.Map<EmployeeWithData>(addedItem);
        }

        // Employee edit address, returns extra data
        // Must do a bit more than a normal "edit existing", because of the association
        // One extra fetch before return so that the associated data comes back
        // Please be aware that there could be alternative coding plans - 
        // the following plan is not authoritative, and others could work
        public EmployeeWithData EmployeeEditAddress(EmployeeEditAddress editedItem)
        {
            // Ensure that we can continue
            if (editedItem == null) { return null; }

            // Attempt to fetch the object
            var storedItem = ds.Employees
                .Include("Employee2")
                .SingleOrDefault(e => e.EmployeeId == editedItem.EmployeeId);

            if (storedItem == null)
            {
                return null;
            }
            else
            {
                // Fetch the object from the data store - ds.Entry(storedItem)
                // Get its current values collection - .CurrentValues
                // Set those to the edited values - .SetValues(editedItem)
                ds.Entry(storedItem).CurrentValues.SetValues(editedItem);
                // The SetValues() method ignores missing properties and navigation properties
                ds.SaveChanges();

                return mapper.Map<EmployeeWithData>(storedItem);
            }
        }

        // Set support rep command
        public void CustomerSetSupportRep(CustomerSupportRep item)
        {
            // Get a reference to the customer
            var customer = ds.Customers.Find(item.CustomerId);
            if (customer == null) { return; }

            // Get a reference to the employee
            var employee = ds.Employees.Find(item.SupportRepId);
            if (employee == null) { return; }

            // Make the changes, save, and exit
            customer.Employee = employee;
            customer.SupportRepId = employee.EmployeeId;
            ds.SaveChanges();
        }

        // ############################################################
        // Invoice

        public IEnumerable<InvoiceWithData> InvoiceGetAll()
        {
            // Invoice get all, with extra data
            var c = ds.Invoices
                .Include("Customer")
                .Take(25)
                .OrderByDescending(i => i.InvoiceDate)
                .ThenBy(i => i.Customer.Company);

            return mapper.Map<IEnumerable<InvoiceWithData>>(c);
        }





        // ############################################################
        // Example

        // Method templates, used by the ExampleController class

        public IEnumerable<string> ExampleGetAll()
        {
            return new List<string> { "hello", "world" };
        }

        public string ExampleGetById(int id)
        {
            return $"id {id} was requested";
        }

        public string ExampleAdd(string newItem)
        {
            return $"new item {newItem} was added";
        }

        public string ExampleEditSomething(string editedItem)
        {
            return $"item was edited with {editedItem}";
        }

        public bool ExampleDelete(int id)
        {
            return true;
        }

    }
}