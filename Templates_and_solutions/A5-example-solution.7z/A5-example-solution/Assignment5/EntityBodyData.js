﻿
// Add one, with and without SupportRepId provided

var withSRI =
    {
        "FirstName": "McIntyre",
        "LastName": "Peter",
        "Company": "Seneca College",
        "Address": "70 The Pond Road",
        "City": "Toronto",
        "State": "ON",
        "Country": "Canada",
        "PostalCode": "M3J 3M6",
        "Phone": "(416) 491-5050",
        "Fax": "(416) 491-5055",
        "Email": "peter@example.com",
        "SupportRepId": 4
    }

var withoutSRI =
    {
        "FirstName": "Ian",
        "LastName": "Tipson",
        "Company": "Seneca College",
        "Address": "70 The Pond Road",
        "City": "Toronto",
        "State": "ON",
        "Country": "Canada",
        "PostalCode": "M3J 3M6",
        "Phone": "(416) 491-5050",
        "Fax": "(416) 491-5055",
        "Email": "ian@example.com"
    }

var withinvalidSRI =
    {
        "FirstName": "Kubba",
        "LastName": "Nagham",
        "Company": "Seneca College",
        "Address": "70 The Pond Road",
        "City": "Toronto",
        "State": "ON",
        "Country": "Canada",
        "PostalCode": "M3J 3M6",
        "Phone": "(416) 491-5050",
        "Fax": "(416) 491-5055",
        "Email": "nagham@example.com",
        "SupportRepId": 44
    }

var editAddress =
    {
        "CustomerId": 12,
        "Address": "1750 Finch Avenue East",
        "City": "Toronto",
        "State": "ON",
        "Country": "Canada",
        "PostalCode": "M2J 2X5"
    }
