
Readme.txt

This is an example solution for Assignment 6 in Fall 2017 web services.
